package formation;

import annotations.Info;

/**
 * @author csl
 * @date 2019/11/28 14:34
 */
@Info(description = "all kinds of Formation")
public enum FormationKind {
    HEYI, YANXING, CHANGSHE,ChongE,YuLin,Fan,Moon,FenShi
}
