package creature.enumeration;

/**
 * @author csl
 * @date 2019/11/27 20:45
 */
public enum Direction {
    UP,DOWN,RIGHT,LEFT
}
