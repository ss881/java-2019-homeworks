package creature.enumeration;

import java.io.Serializable;

/**
 * @author csl
 * @date 2019/11/25 19:32
 */
//就两种阵营:justice和 evil
public enum Camp implements Serializable {
JUSTICE,EVIL
}
